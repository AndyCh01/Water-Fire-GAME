import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

const PORT = process.env.PORT || 3000;

// Almacén de salas activas en memoria
const rooms = {};

// Generador de código aleatorio de 5 letras/números legibles
function generateRoomCode() {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let code = '';
  for (let i = 0; i < 5; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  if (rooms[code]) return generateRoomCode();
  return code;
}

// Eventos de Socket.io y lógica de salas
io.on('connection', (socket) => {
  console.log(`[Socket conectado] ID: ${socket.id}`);

  // 1. CREAR SALA (Asigna rol FUEGO al creador)
  socket.on('createRoom', () => {
    const roomCode = generateRoomCode();
    rooms[roomCode] = {
      code: roomCode,
      players: [{ id: socket.id, role: 'fire' }],
      level: 1,
    };

    socket.join(roomCode);
    socket.data.roomCode = roomCode;
    socket.data.role = 'fire';

    console.log(`[Sala Creada] Código: ${roomCode} | Creador: ${socket.id} (FUEGO)`);

    socket.emit('roomCreated', {
      roomCode,
      role: 'fire',
    });
  });

  // 2. UNIRSE A SALA (Asigna rol AGUA al segundo jugador)
  socket.on('joinRoom', ({ roomCode: rawCode }) => {
    const roomCode = (rawCode || '').trim().toUpperCase();
    const room = rooms[roomCode];

    if (!room) {
      socket.emit('joinError', {
        message: 'Sala no encontrada. Verifica el código de 5 dígitos.',
      });
      return;
    }

    if (room.players.length >= 2) {
      socket.emit('joinError', {
        message: 'La sala ya está completa (máximo 2 jugadores).',
      });
      return;
    }

    // Unir a la sala como AGUA
    room.players.push({ id: socket.id, role: 'water' });
    socket.join(roomCode);
    socket.data.roomCode = roomCode;
    socket.data.role = 'water';

    console.log(`[Unido a Sala] Código: ${roomCode} | Jugador: ${socket.id} (AGUA)`);

    socket.emit('roomJoined', {
      roomCode,
      role: 'water',
    });

    // ¡Ambos jugadores están en la sala! Emitir gameStart a la sala
    io.to(roomCode).emit('gameStart', {
      roomCode,
      level: room.level,
      players: room.players,
    });
  });

  // 3. SINCRONIZACIÓN DE MOVIMIENTO
  socket.on('playerMove', (payload) => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;
    socket.to(roomCode).emit('playerMove', {
      role: socket.data.role,
      ...payload,
    });
  });

  // 4. SINCRONIZACIÓN DE RECOLECCIÓN DE GEMAS
  socket.on('gemCollect', (payload) => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;
    socket.to(roomCode).emit('gemCollect', payload);
  });

  // 5. INTERRUPTORES / PALANCAS
  socket.on('leverToggle', (payload) => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;
    socket.to(roomCode).emit('leverToggle', payload);
  });

  // 6. PLACAS DE PRESIÓN
  socket.on('plateState', (payload) => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;
    socket.to(roomCode).emit('plateState', payload);
  });

  // 7. CAJAS EMPUJABLES
  socket.on('boxMove', (payload) => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;
    socket.to(roomCode).emit('boxMove', payload);
  });

  // 8. RUNAS ELEMENTALES (Nivel 3)
  socket.on('runeProgress', (payload) => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;
    socket.to(roomCode).emit('runeProgress', payload);
  });

  // 9. MUERTE / REINICIO
  socket.on('playerDeath', (payload) => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;
    socket.to(roomCode).emit('playerDeath', payload);
  });

  socket.on('levelRestart', () => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;
    io.to(roomCode).emit('levelRestart');
  });

  socket.on('levelChange', (payload) => {
    const roomCode = socket.data.roomCode;
    if (!roomCode || !rooms[roomCode]) return;
    rooms[roomCode].level = payload.levelId;
    io.to(roomCode).emit('levelChange', payload);
  });

  socket.on('levelVictory', (payload) => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;
    socket.to(roomCode).emit('levelVictory', payload);
  });

  // 10. ABANDONAR O DESCONEXIÓN
  socket.on('leaveRoom', () => {
    const roomCode = socket.data.roomCode;
    if (!roomCode) return;

    socket.leave(roomCode);
    socket.to(roomCode).emit('playerLeft', {
      message: 'El otro jugador abandonó la partida.',
    });

    if (rooms[roomCode]) {
      rooms[roomCode].players = rooms[roomCode].players.filter((p) => p.id !== socket.id);
      if (rooms[roomCode].players.length === 0) {
        delete rooms[roomCode];
      }
    }

    socket.data.roomCode = null;
    socket.data.role = null;
  });

  socket.on('disconnect', () => {
    const roomCode = socket.data.roomCode;
    if (roomCode && rooms[roomCode]) {
      rooms[roomCode].players = rooms[roomCode].players.filter((p) => p.id !== socket.id);
      socket.to(roomCode).emit('playerLeft', {
        message: 'El otro jugador se ha desconectado.',
      });

      if (rooms[roomCode].players.length === 0) {
        delete rooms[roomCode];
      }
    }
  });
});

// Servir archivos compilados en producción
app.use(express.static(path.resolve(__dirname, 'dist')));
app.get('*', (req, res) => {
  res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
});

httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor Water-Fire en ejecución en puerto ${PORT}`);
});
