import express from 'express';
import { createServer } from 'http';
import { Server, Socket } from 'socket.io';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface RoomPlayer {
  id: string;
  role: 'fire' | 'water';
}

interface Room {
  code: string;
  players: RoomPlayer[];
  level: number;
}

const rooms: Record<string, Room> = {};

// Generate 5-character readable room code (no 0/O, 1/I ambiguity)
function generateRoomCode(): string {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let code = '';
  for (let i = 0; i < 5; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  // Ensure unique
  if (rooms[code]) {
    return generateRoomCode();
  }
  return code;
}

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST'],
    },
  });

  const PORT = Number(process.env.PORT) || 3000;

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', activeRooms: Object.keys(rooms).length });
  });

  // Socket.io Connection & Room Logic
  io.on('connection', (socket: Socket) => {
    console.log(`[Socket] User connected: ${socket.id}`);

    // CREATE ROOM (Host: Role Fire)
    socket.on('createRoom', () => {
      const roomCode = generateRoomCode();
      const room: Room = {
        code: roomCode,
        players: [{ id: socket.id, role: 'fire' }],
        level: 1,
      };

      rooms[roomCode] = room;
      socket.join(roomCode);
      socket.data.roomCode = roomCode;
      socket.data.role = 'fire';

      console.log(`[Room Created] Code: ${roomCode} by ${socket.id} (Role: FUEGO)`);

      socket.emit('roomCreated', {
        roomCode,
        role: 'fire',
      });
    });

    // JOIN ROOM (Guest: Role Water)
    socket.on('joinRoom', (data: { roomCode: string }) => {
      const rawCode = data?.roomCode || '';
      const roomCode = rawCode.trim().toUpperCase();
      const room = rooms[roomCode];

      if (!room) {
        socket.emit('joinError', {
          message: 'Sala no encontrada. Verifica el código de 5 caracteres.',
        });
        return;
      }

      if (room.players.length >= 2) {
        socket.emit('joinError', {
          message: 'La sala ya está llena (máximo 2 jugadores).',
        });
        return;
      }

      // Assign Water to second player
      room.players.push({ id: socket.id, role: 'water' });
      socket.join(roomCode);
      socket.data.roomCode = roomCode;
      socket.data.role = 'water';

      console.log(`[Room Joined] Code: ${roomCode} by ${socket.id} (Role: AGUA)`);

      socket.emit('roomJoined', {
        roomCode,
        role: 'water',
      });

      // Both players are present: START GAME!
      io.to(roomCode).emit('gameStart', {
        roomCode,
        level: room.level,
        players: room.players,
      });

      console.log(`[Game Started] Room ${roomCode} has 2 players, starting match!`);
    });

    // PLAYER MOVEMENT SYNC
    socket.on('playerMove', (payload) => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;
      socket.to(roomCode).emit('playerMove', {
        role: socket.data.role,
        ...payload,
      });
    });

    // GEM COLLECTION SYNC
    socket.on('gemCollect', (payload) => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;
      socket.to(roomCode).emit('gemCollect', payload);
    });

    // LEVER INTERACTION SYNC
    socket.on('leverToggle', (payload) => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;
      socket.to(roomCode).emit('leverToggle', payload);
    });

    // PRESSURE PLATE SYNC
    socket.on('plateState', (payload) => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;
      socket.to(roomCode).emit('plateState', payload);
    });

    // PUSHABLE BOX SYNC
    socket.on('boxMove', (payload) => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;
      socket.to(roomCode).emit('boxMove', payload);
    });

    // RUNE PILLAR SYNC (Level 3 Guardian)
    socket.on('runeProgress', (payload) => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;
      socket.to(roomCode).emit('runeProgress', payload);
    });

    // PLAYER DEATH / GAME OVER
    socket.on('playerDeath', (payload) => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;
      socket.to(roomCode).emit('playerDeath', payload);
    });

    // RESTART LEVEL SYNC
    socket.on('levelRestart', () => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;
      io.to(roomCode).emit('levelRestart');
    });

    // LEVEL CHANGE / NEXT LEVEL
    socket.on('levelChange', (payload: { levelId: number }) => {
      const roomCode = socket.data.roomCode;
      if (!roomCode || !rooms[roomCode]) return;
      rooms[roomCode].level = payload.levelId;
      io.to(roomCode).emit('levelChange', payload);
    });

    // LEVEL VICTORY SYNC
    socket.on('levelVictory', (payload) => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;
      socket.to(roomCode).emit('levelVictory', payload);
    });

    // LEAVE ROOM
    socket.on('leaveRoom', () => {
      const roomCode = socket.data.roomCode;
      if (!roomCode) return;

      socket.leave(roomCode);
      socket.to(roomCode).emit('playerLeft', {
        message: 'El compañero de equipo ha salido de la sala.',
      });

      if (rooms[roomCode]) {
        rooms[roomCode].players = rooms[roomCode].players.filter((p) => p.id !== socket.id);
        if (rooms[roomCode].players.length === 0) {
          delete rooms[roomCode];
        }
      }

      socket.data.roomCode = null;
      socket.data.role = null;
    });

    // DISCONNECT
    socket.on('disconnect', () => {
      const roomCode = socket.data.roomCode;
      console.log(`[Socket] Disconnected: ${socket.id}`);

      if (roomCode && rooms[roomCode]) {
        rooms[roomCode].players = rooms[roomCode].players.filter((p) => p.id !== socket.id);
        socket.to(roomCode).emit('playerLeft', {
          message: 'El otro jugador se ha desconectado.',
        });

        if (rooms[roomCode].players.length === 0) {
          delete rooms[roomCode];
          console.log(`[Room Deleted] Room ${roomCode} cleaned up.`);
        }
      }
    });
  });

  // Serve static files in production or Vite middleware in development
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`🔥💧 Water-Fire Server with Socket.io running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
